const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  // 默认直接打包的项目代码，必须直接丢在 服务器根目录 运行
  // 所有资源（js css img）的访问都是基于根路径，以绝对路径访问
  // publicPath: '/'

  // 如果想要在 任意目录 都能直接运行，甚至希望能直接双击运行
  // 需要将 publicPath 配置成相对路径, 重新打包
  publicPath: './',

  css: {
    loaderOptions: {
      less: {
        lessOptions: {
          modifyVars: {
            // 直接覆盖变量
            blue: '#FA6D1D'
          }
        }
      }
    }
  }
})
