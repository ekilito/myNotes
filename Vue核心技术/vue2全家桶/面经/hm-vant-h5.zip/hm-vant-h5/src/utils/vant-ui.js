import Vue from 'vue'
import {
  Button,
  Checkbox,
  Tabbar,
  TabbarItem,
  NavBar,
  Form,
  Field,
  Toast,
  Cell,
  List,
  Icon,
  Grid,
  GridItem,
  CellGroup
} from 'vant'

Vue.use(Grid)
Vue.use(GridItem)
Vue.use(CellGroup)
Vue.use(Icon)
Vue.use(List)
Vue.use(Cell)
Vue.use(Toast)
Vue.use(Button)
Vue.use(Checkbox)
Vue.use(Tabbar)
Vue.use(TabbarItem)
Vue.use(NavBar)
Vue.use(Form)
Vue.use(Field)
