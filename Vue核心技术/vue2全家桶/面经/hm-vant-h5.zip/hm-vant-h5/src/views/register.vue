<template>
  <div class="login-page">
    <van-nav-bar title="面经注册" />

    <van-form @submit="onSubmit">
      <van-field
        v-model="username"
        name="username"
        label="用户名"
        placeholder="用户名"
        :rules="[
          { required: true, message: '请填写用户名' },
          { pattern: /^\w{5,}$/, message: '长度必须5个字符以上' },
        ]"
      />
      <van-field
        v-model="password"
        type="password"
        name="password"
        label="密码"
        placeholder="密码"
        :rules="[
          { required: true, message: '请填写密码' },
          { pattern: /^\w{6,}$/, message: '长度必须6个字符以上' },
        ]"
      />
      <div style="margin: 16px">
        <van-button block type="primary" native-type="submit">注册</van-button>
      </div>
    </van-form>
    <router-link class="link" to="/login">有账号，去登录</router-link>
  </div>
</template>

<script>
// import { Toast } from 'vant'
import { register } from '@/api/user'

export default {
  name: 'register-page',
  data () {
    return {
      username: '',
      password: ''
    }
  },
  methods: {
    async onSubmit (values) {
      // 发送注册的请求
      // try catch 尝试执行 try 代码块的逻辑，如果有错误，会被 catch 捕获，存入 e 中
      await register(values)
      this.$toast.success('注册成功！')
      this.$router.push('/login')
    }
  }
}

// console.log('submit', values)
// Toast('普通提示')

// Toast.loading({
//   message: '拼命加载中...',
//   forbidClick: true,
//   duration: 0 // 永远不自动消失
// })

// setTimeout(() => {
//   console.log('3秒后, 请求回来了')
//   // Toast.clear()
//   Toast.success('恭喜注册成功')
// }, 3000)

// 必须在组件实例范围内，this指向某个组件实例，才能这么用
// this.$toast.fail('失败了')
</script>

<style lang="less" scoped>
.link {
  color: #069;
  font-size: 12px;
  padding-right: 20px;
  float: right;
}
</style>
